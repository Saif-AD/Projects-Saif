from django.core.management.base import BaseCommand, CommandError

from tutorials.models import User, Tutor, Availability, StudentRequest
from datetime import time

import pytz
from faker import Faker
from random import randint, random

user_fixtures = [
    {'username': '@johndoe', 'email': 'john.doe@example.org', 'first_name': 'John', 'last_name': 'Doe', 'account_type': 'admin'},
    {'username': '@janedoe', 'email': 'jane.doe@example.org', 'first_name': 'Jane', 'last_name': 'Doe', 'account_type': 'tutor'},
    {'username': '@charlie', 'email': 'charlie.johnson@example.org', 'first_name': 'Charlie', 'last_name': 'Johnson', 'account_type': 'student'},
]

ACCOUNT_TYPES = ['student', 'tutor', 'admin']
SUBJECT_CHOICES = ['Physics', 'Maths', 'Chemistry','Biology', 'Economics', 'History', 'Geography']
WEEK_DAYS_CHOICES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
DURATION_CHOICES = ['15m', '30m', '1h']

class Command(BaseCommand):
    """Build automation command to seed the database."""

    USER_COUNT = 51
    DEFAULT_PASSWORD = 'Password123'
    help = 'Seeds the database with sample data'

    def __init__(self):
        self.faker = Faker('en_GB')

    def handle(self, *args, **options):
        self.create_users()
        self.users = User.objects.all()

    def create_users(self):
        print("Seeding users...")
        self.generate_user_fixtures()
        self.generate_students(24)
        self.generate_tutors(24)
        print("User seeding complete.")

    def generate_user_fixtures(self):
        for data in user_fixtures:
            self.try_create_user(data)

    def generate_random_users(self):
        user_count = User.objects.count()
        while  user_count < self.USER_COUNT:
            print(f"Seeding user {user_count}/{self.USER_COUNT}", end='\r')
            self.generate_user()
            user_count = User.objects.count()
        print("User seeding complete.      ")

    def generate_user(self):

        random_account_type = ACCOUNT_TYPES[randint(0,1)]
        self.generate_user_of_type(random_account_type)

    def generate_students(self, number):

        for i in range(number):
            self.generate_user_of_type(ACCOUNT_TYPES[0])

    def generate_tutors(self, number):

        for i in range(number):
            self.generate_user_of_type(ACCOUNT_TYPES[1])

    def generate_user_of_type(self, data):

        first_name = self.faker.first_name()
        last_name = self.faker.last_name()
        email = create_email(first_name, last_name)
        username = create_username(first_name, last_name)

        self.try_create_user({'username': username, 'email': email, 'first_name': first_name, 'last_name': last_name, 'account_type': data})


    def try_create_user(self, data):
        try:
            self.create_user(data)
        except:
            pass

    def create_user(self, data):
        user = User.objects.create_user(
            username=data['username'],
            email=data['email'],
            password=Command.DEFAULT_PASSWORD,
            first_name=data['first_name'],
            last_name=data['last_name'],
            account_type=data['account_type']
        )
        if user.account_type == 'tutor':

            random_subject = SUBJECT_CHOICES[randint(0, len(SUBJECT_CHOICES) - 1)]
            tutor = Tutor.objects.create(
                user=user,
                subject=random_subject,
                hourly_rate= 50.00,
            )

            # Number of availabilities for the tutor
            random_number = randint(1,4)
            for i in range(random_number):
                random_day = WEEK_DAYS_CHOICES[randint(0, len(WEEK_DAYS_CHOICES) - 1)]
                random_start_time = randint(9,17)
                start_time = time(random_start_time)
                end_time = time(random_start_time + randint(1,2))

                # check overlap
                overlap = False
                overlap_availabilities = Availability.objects.filter(tutor=tutor)
                for avail in overlap_availabilities:
                    if avail.day == random_day:
                        if (avail.start_time <= start_time < avail.end_time or
                                avail.start_time < end_time <= avail.end_time):
                            overlap = True

                if not overlap:
                    availability = Availability.objects.create(
                        tutor=tutor,
                        day=random_day,
                        start_time=start_time,
                        end_time=end_time,
                    )

        elif user.account_type == 'student':

            # Number of lesson requests for the student
            random_number = randint(0, 1)

            for i in range(random_number):
                random_subject = SUBJECT_CHOICES[randint(0, len(SUBJECT_CHOICES) - 1)]
                random_duration = DURATION_CHOICES[randint(0, len(DURATION_CHOICES) - 1)]
                request = StudentRequest.objects.create(
                    student=user,
                    subject=random_subject,
                    duration=random_duration,
                )




def create_username(first_name, last_name):
    return '@' + first_name.lower() + last_name.lower()

def create_email(first_name, last_name):
    return first_name + '.' + last_name + '@example.org'
