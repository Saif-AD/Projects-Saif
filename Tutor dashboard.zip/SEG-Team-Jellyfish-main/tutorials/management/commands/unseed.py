from django.core.management.base import BaseCommand, CommandError
from django.apps import apps

class Command(BaseCommand):
    """Build automation command to unseed the database."""
    
    help = 'Seeds the database with sample data'

    def handle(self, *args, **options):
        """Unseed the database."""
        for model in apps.get_models():
            print(f"Deleting all records from {model.__name__}...")
            model.objects.all().delete()
        print("Database reset complete.")