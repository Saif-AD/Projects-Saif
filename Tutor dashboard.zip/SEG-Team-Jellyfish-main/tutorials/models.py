from django.core.validators import RegexValidator
from django.contrib.auth.models import AbstractUser
from django.db import models
from libgravatar import Gravatar
from django.conf import settings
from django.utils.timezone import now
from django.db.models.signals import post_save
from django.dispatch import receiver
from datetime import timedelta, datetime
from django.core.exceptions import ValidationError
from decimal import Decimal

class User(AbstractUser):
    """Model used for user authentication, and team member related information."""
    ACCOUNT_TYPE_CHOICES = (
        ('student', 'Student'),
        ('tutor', 'Tutor'),
        ('admin', 'Admin'),
    )
    username = models.CharField(
        max_length=30,
        unique=True,
        validators=[RegexValidator(
            regex=r'^@\w{3,}$',
            message='Username must consist of @ followed by at least three alphanumericals'
        )]
    )
    first_name = models.CharField(max_length=50, blank=False)
    last_name = models.CharField(max_length=50, blank=False)
    email = models.EmailField(unique=True, blank=False)
    account_type = models.CharField(max_length=10, choices=ACCOUNT_TYPE_CHOICES, default='student')

    class Meta:
        """Model options."""

        ordering = ['last_name', 'first_name']

    def full_name(self):
        """Return a string containing the user's full name."""

        return f'{self.first_name} {self.last_name}'

    def gravatar(self, size=120):
        """Return a URL to the user's gravatar."""

        gravatar_object = Gravatar(self.email)
        gravatar_url = gravatar_object.get_image(size=size, default='mp')
        return gravatar_url

    def mini_gravatar(self):
        """Return a URL to a miniature version of the user's gravatar."""
        
        return self.gravatar(size=60)

class Tutor(models.Model):
    """Model used for users of type Tutor."""

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='tutor_profile')

    # Dropdown list for choosing the subject
    SUBJECT_CHOICES = [
        ('Physics', 'physics'),
        ('Maths', 'maths'),
        ('Chemistry', 'chemistry'),
        ("Biology", 'biology'),
        ('Economics', 'economics'),
        ('History', 'history'),
        ('Geography', 'geography')
    ]
    subject = models.CharField(max_length=100, choices=SUBJECT_CHOICES, null=False)
    hourly_rate = models.DecimalField(max_digits=6, decimal_places=2, default=50.00)
    def __str__(self):
        return f"{self.user.username}"


class Availability(models.Model):
    """Model used by Tutor to manage availability"""

    tutor = models.ForeignKey(Tutor, on_delete=models.CASCADE, related_name='availability')

    # Dropdown list for choosing the day
    WEEK_DAYS_CHOICES = [
        ('Monday', 'Monday'),
        ('Tuesday', 'Tuesday'),
        ('Wednesday', 'Wednesday'),
        ('Thursday', 'Thursday'),
        ('Friday', 'Friday'),
        ('Saturday', 'Saturday'),
        ('Sunday', 'Sunday'),
    ]
    day = models.CharField(max_length=10, choices=WEEK_DAYS_CHOICES)

    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return f"{self.tutor.user.first_name} {self.tutor.user.last_name} - {self.day} ({self.start_time} - {self.end_time})"


class StudentRequest(models.Model):
    """Model used by Student to manage lesson requests"""

    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name="requests")

    # Dropdown list for choosing the subject
    SUBJECT_CHOICES = [
        ('Physics', 'Physics'),
        ('Maths', 'Maths'),
        ('Chemistry', 'Chemistry'),
        ('Biology', 'Biology'),
        ('Economics', 'Economics'),
        ('History', 'History'),
        ('Geography', 'Geography'),
    ]
    subject = models.CharField(max_length=100, choices=SUBJECT_CHOICES, null=False)

    # Dropdown list for choosing the duration
    DURATION_CHOICES = [
        ('15m', '15m'),
        ('30m', '30m'),
        ('1h', '1h')
    ]
    duration = models.CharField(max_length=10, choices=DURATION_CHOICES, null=False)
    date_requested = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f'{self.student.first_name} {self.student.last_name} - subject: {self.subject} ({self.duration})'
    
class Invoice(models.Model):
    """
    Represents an invoice for lessons.
    Tracks payment status, total amount, and related entities.
    """
    STATUS_CHOICES = [
        ('unpaid', 'Unpaid'),
        ('paid', 'Paid'),
        ('overdue', 'Overdue'),
    ]

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='invoices',
        limit_choices_to={'account_type': 'student'},
        help_text="The student associated with this invoice."
    )
    tutor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='tutor_invoices',
        limit_choices_to={'account_type': 'tutor'},
        help_text="The tutor associated with this invoice.",
        null=True,
        blank=True
    )
    lesson = models.ForeignKey(
        'AllocatedLessons',
        on_delete=models.CASCADE,
        related_name='invoices',
        help_text="The lesson associated with this invoice.",
        null=True,  # Allow null temporarily
        blank=True  # Allow blank in forms temporarily
    )
    issued_date = models.DateField(default=now, help_text="The date the invoice was issued.")
    due_date = models.DateField(help_text="The date by which payment is due.")
    total_amount = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="Total amount to be paid."
    )
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='unpaid',
        help_text="Payment status of the invoice."
    )

    def is_overdue(self):
        """
        Check if the invoice is overdue.
        """
        return self.status == 'unpaid' and self.due_date < now().date()

    def mark_as_paid(self):
        """
        Mark the invoice as paid.
        """
        self.status = 'paid'
        self.save()

    def __str__(self):
        """
        String representation of the invoice.
        """
        return f"Invoice #{self.id} - {self.student.username} - {self.tutor.username} - {self.status}"
    
class AllocatedLessons(models.Model):
    """Represents the lessons allocated to a tutor."""
    student_request = models.OneToOneField(StudentRequest, on_delete=models.CASCADE, related_name='allocation', null=True)
    tutor = models.ForeignKey(Tutor, on_delete=models.CASCADE, related_name='allocated_lessons')
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='allocated_lessons')
    subject = models.CharField(max_length=100)
    WEEK_DAYS_CHOICES = [
        ('Monday', 'Monday'),
        ('Tuesday', 'Tuesday'),
        ('Wednesday', 'Wednesday'),
        ('Thursday', 'Thursday'),
        ('Friday', 'Friday'),
        ('Saturday', 'Saturday'),
        ('Sunday', 'Sunday'),
    ]
    day_of_week = models.CharField(max_length=10, choices=WEEK_DAYS_CHOICES, null=True)
    start_time = models.TimeField()
    end_time = models.TimeField()

    def __str__(self):
        return f"{self.tutor.user.username} - {self.student.username} - {self.subject} - {self.day_of_week} ({self.start_time} - {self.end_time})"

@receiver(post_save, sender=AllocatedLessons)
def create_invoice_for_allocated_lesson(sender, instance, created, **kwargs):
    """
    Signal to create an invoice when a new lesson is added.
    """
    if created:
        # Use a fixed dummy date for the calculation
        dummy_date = datetime.today().date()
        start_datetime = datetime.combine(dummy_date, instance.start_time)
        end_datetime = datetime.combine(dummy_date, instance.end_time)

        # Calculate duration in hours
        duration_in_hours = Decimal((end_datetime - start_datetime).seconds) / Decimal(3600)
        hourly_rate = instance.tutor.hourly_rate
        total_amount = duration_in_hours * hourly_rate
        #sets due date to two weeks
        due_date = now().date() + timedelta(days=14)
        #creates invoice
        Invoice.objects.create(
            lesson=instance,
            student=instance.student,
            tutor=instance.tutor.user,
            issued_date=now().date(),
            due_date=due_date,
            total_amount=total_amount,
            status='unpaid'
        )