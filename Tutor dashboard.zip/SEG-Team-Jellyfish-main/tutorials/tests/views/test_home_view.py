"""Tests of the home view."""
from django.test import TestCase
from django.urls import reverse
from tutorials.models import User, Tutor

class HomeViewTestCase(TestCase):
    """Tests of the home view."""

    fixtures = ['tutorials/tests/fixtures/default_user.json']

    def setUp(self):
        self.url = reverse('home')

        self.tutor = User.objects.get(username='@janedoeT')
        self.student = User.objects.get(username='@charlieT')
        self.admin = User.objects.get(username='@johndoeT')

    def test_home_url(self):
        self.assertEqual(self.url,'/')

    def test_get_home(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'home.html')

    def test_get_dashboard_redirects_when_logged_in_tutor(self):
        self.client.login(username=self.tutor.username, password="Password123")
        response = self.client.get(reverse('log_in'), follow=True)
        redirect_url = reverse('tutor_dashboard')
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'tutor_dashboard.html')

    def test_get_dashboard_redirects_when_logged_in_student(self):
        self.client.login(username=self.student.username, password="Password123")
        response = self.client.get(reverse('log_in'), follow=True)
        redirect_url = reverse('dashboard')
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'student_dashboard.html')

    def test_get_dashboard_redirects_when_logged_in_admin(self):
        self.client.login(username=self.admin.username, password="Password123")
        response = self.client.get(reverse('log_in'), follow=True)
        redirect_url = reverse('dashboard')
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
        self.assertTemplateUsed(response, 'admin_dashboard.html')

    def test_homepage_status_code(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)

    def test_homepage_template(self):
        response = self.client.get(reverse('home'))
        self.assertTemplateUsed(response, 'home.html')