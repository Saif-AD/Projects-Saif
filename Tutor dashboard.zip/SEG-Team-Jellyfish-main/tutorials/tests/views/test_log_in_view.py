"""Tests of the log in view."""
from django.contrib import messages
from django.test import TestCase
from django.urls import reverse
from tutorials.forms import LogInForm
from tutorials.models import User
from tutorials.tests.test_helpers import reverse_with_next

class LogInViewTestCase(TestCase):
    """Tests of the log in view."""

    def setUp(self):
        self.url = reverse('log_in')
        self.user = User.objects.create_user(username="testuser", password="securepassword")

    def tearDown(self):
        User.objects.all().delete()

    def test_log_in_url(self):
        url = reverse('log_in')
        self.assertEqual(url, '/log_in/')

    def test_get_log_in(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'log_in.html')
        form = response.context['form']
        next = response.context.get('next')
        self.assertTrue(isinstance(form, LogInForm))
        self.assertFalse(form.is_bound)
        self.assertFalse(next) 
        messages_list = list(response.context['messages'])
        self.assertEqual(len(messages_list), 0)

    def test_get_log_in_with_redirect(self):
        destination_url = reverse('profile')
        self.url = reverse_with_next('log_in', destination_url)
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'log_in.html')

    def test_get_log_in_redirects_when_logged_in(self):
        self.client.login(username=self.user.username, password="securepassword")
        response = self.client.get(self.url, follow=True)
        redirect_url = reverse('dashboard') 
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)

    def test_unsuccesful_log_in(self):
        response = self.client.post(self.url, {'username': 'invalid', 'password': 'wrongpassword'})
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'log_in.html')
        self.assertContains(response, "The credentials provided were invalid!")  
        self.assertFalse(self._is_logged_in())  

    def test_succesful_log_in(self):
        response = self.client.post(self.url, {'username': 'testuser', 'password': 'securepassword'})
        self.assertRedirects(response, reverse('dashboard'))  
        self.assertTrue(self._is_logged_in()) 

    def test_log_in_with_empty_data(self):
        response = self.client.post(self.url, {'username': '', 'password': ''})
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'log_in.html')
        self.assertContains(response, "The credentials provided were invalid!") 
        self.assertFalse(self._is_logged_in())  

    def _is_logged_in(self):
        return '_auth_user_id' in self.client.session
