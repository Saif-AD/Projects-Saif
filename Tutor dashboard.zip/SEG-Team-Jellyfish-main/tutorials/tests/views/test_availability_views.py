"""Tests of the availability view."""
from django.test import TestCase
from django.urls import reverse
from tutorials.models import User, Tutor, Availability
from tutorials.forms import AvailabilityForm
from datetime import time
from django.http import Http404, HttpResponseForbidden

class AddAvailabilityViewTestCase(TestCase):
    """Tests of the add_availability view."""

    fixtures = ['tutorials/tests/fixtures/default_user.json']

    def setUp(self):

        self.tutor = User.objects.get(username='@janedoeT')
        self.tutor_profile = self.tutor.tutor_profile

        self.add_availability_url = reverse('add_availability')
        self.tutor_dashboard_url = reverse('tutor_dashboard')

        self.valid_availability = {
            'day': 'Friday',
            'start_time': time(13, 0),
            'end_time': time(14, 0),
        }
        self.invalid_availability = {
            'day': 'Friday',
            'start_time': time(14, 0),
            'end_time': time(13, 0),
        }

        self.client.login(username=self.tutor.username, password="Password123")

    def test_add_valid_availability(self):
        count_before = Availability.objects.count()
        response = self.client.post(self.add_availability_url, self.valid_availability, follow=True)
        self.assertRedirects(response, self.tutor_dashboard_url)
        self.assertEqual(Availability.objects.count(), count_before + 1)

    def test_invalid_availability(self):
        count_before = Availability.objects.count()
        response = self.client.post(self.add_availability_url, self.invalid_availability, follow=True)
        self.assertEqual(Availability.objects.count(), count_before)
        self.assertContains(response, "Availability invalid: end_time must be after start_time")

    def test_add_overlapping_availability(self):
        overlapping_availability = Availability.objects.create(
            tutor=self.tutor_profile,
            day= 'Friday',
            start_time= time(13, 0),
            end_time= time(14, 0),
        )
        count_before = Availability.objects.count()
        response = self.client.post(self.add_availability_url, self.valid_availability, follow=True)
        self.assertEqual(Availability.objects.count(), count_before)
        self.assertRedirects(response, self.tutor_dashboard_url)
        self.assertContains(response, "Availability overlaps with another Availability you have registered!")

    def test_non_post_request(self):
        response = self.client.get(self.add_availability_url)
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, self.tutor_dashboard_url)

class DeleteAvailabilityViewTestCase(TestCase):
    """Tests of the delete_availability view."""

    fixtures = ['tutorials/tests/fixtures/default_user.json']

    def setUp(self):
        self.tutor = User.objects.get(username='@janedoeT')
        self.tutor_profile = self.tutor.tutor_profile

        self.other_tutor = User.objects.create_user(
            username='@otherTutor',
            email='otherTutor@example.org',
            first_name= 'Other',
            last_name='Tutor',
            account_type= 'tutor',
            password='Password123',
        )
        self.other_tutor_profile = Tutor.objects.create(
            user= self.other_tutor,
            subject= 'Maths',
        )

        self.availability = Availability.objects.create(
            tutor=self.tutor_profile,
            day='Friday',
            start_time=time(13, 0),
            end_time=time(14, 0),
        )

        self.delete_availability_url = reverse('delete_availability', kwargs={'availability_id': self.availability.id})
        self.client.login(username=self.tutor.username, password="Password123")

    def test_delete_availability(self):
        count_before = Availability.objects.count()
        response = self.client.post(self.delete_availability_url, follow=True)
        self.assertRedirects(response, reverse('tutor_dashboard'))
        self.assertEqual(Availability.objects.count(), count_before - 1)
        with self.assertRaises(Availability.DoesNotExist):
            Availability.objects.get(id=self.availability.id)

    def test_delete_availability_invalid_id(self):
        invalid_id_url = reverse('delete_availability', kwargs={'availability_id': 936410938610})
        response = self.client.post(invalid_id_url, follow=True)
        self.assertEqual(response.status_code, 404)

    def test_delete_availability_not_owned_by_tutor(self):
        other_availability = Availability.objects.create(
            tutor=self.other_tutor_profile,
            day='Friday',
            start_time=time(13, 0),
            end_time=time(14, 0),
        )
        other_url = reverse('delete_availability', kwargs={'availability_id': other_availability.id})
        response = self.client.post(other_url, follow=True)
        self.assertEqual(response.status_code, 403)
        # Confirm availability was not deleted
        self.assertTrue(Availability.objects.filter(id=other_availability.id).exists())

    def test_non_post_request(self):
        response = self.client.get(self.delete_availability_url)
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, reverse('tutor_dashboard'))