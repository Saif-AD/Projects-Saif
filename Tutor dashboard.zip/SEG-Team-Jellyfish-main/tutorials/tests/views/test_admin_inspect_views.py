"""Tests of the admin inspect utility."""
from django.test import TestCase
from django.urls import reverse
from tutorials.models import User, Tutor, Availability, Invoice, AllocatedLessons
from django.http import Http404
from datetime import time

class InspectDashboardViewTestCase(TestCase):
    """Tests of the admin inspect dashboard views."""

    fixtures = ['tutorials/tests/fixtures/default_user.json']

    def setUp(self):

        self.admin = User.objects.get(username='@johndoeT')
        self.tutor = User.objects.get(username='@janedoeT')
        self.student = User.objects.get(username='@charlieT')
        self.tutor_profile = self.tutor.tutor_profile

        self.inspect_student_url = reverse('inspect_student', kwargs={'student_id': self.student.id})
        self.inspect_tutor_url = reverse('inspect_tutor', kwargs={'tutor_id': self.tutor_profile.id})
        self.admin_dashboard_url = reverse('admin_dashboard')

        self.client.login(username=self.admin.username, password="Password123")

    def test_inspect_tutor_post_request(self):
        response = self.client.post(self.inspect_tutor_url, follow=True)

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'tutor_dashboard_as_admin.html')

        self.assertIn('tutorToInspect', response.context)
        self.assertEqual(response.context['tutorToInspect'], self.tutor_profile)

        self.assertIn('availabilities', response.context)
        self.assertIn('invoices', response.context)
        self.assertIn('allocated_lessons', response.context)

    def test_inspect_tutor_invalid_id(self):
        invalid_url = reverse('inspect_tutor', kwargs={'tutor_id': 9201486394})
        response = self.client.post(invalid_url, follow=True)
        self.assertEqual(response.status_code, 404)

    def test_inspect_tutor_get_request(self):
        response = self.client.get(self.inspect_tutor_url, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard.html')

    def test_inspect_student_post_request(self):
        response = self.client.post(self.inspect_student_url, follow=True)
        self.assertEqual(response.status_code, 200)

        self.assertTemplateUsed(response, 'student_dashboard_as_admin.html')
        self.assertIn('studentToInspect', response.context)

        self.assertEqual(response.context['studentToInspect'], self.student)
        self.assertIn('requests', response.context)
        self.assertIn('invoices', response.context)
        self.assertIn('allocated_lessons', response.context)

    def test_inspect_student_invalid_id(self):
        invalid_url = reverse('inspect_student', kwargs={'student_id': 9201486394})
        response = self.client.post(invalid_url, follow=True)
        self.assertEqual(response.status_code, 404)

    def test_inspect_student_get_request(self):
        response = self.client.get(self.inspect_student_url, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard.html')