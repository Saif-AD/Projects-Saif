from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model

User = get_user_model()

class LogOutViewTestCase(TestCase):
    """Tests of the log out view."""

    def setUp(self):
        self.user = User.objects.create_user(username="testuser", password="securepassword")
        self.url = reverse('log_out')

    def _is_logged_in(self):
        """Check if a user is logged in."""
        return '_auth_user_id' in self.client.session

    def test_get_log_out(self):
        self.client.login(username=self.user.username, password="securepassword")
        self.assertTrue(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        self.assertFalse(self._is_logged_in())
        redirect_url = reverse('log_in') 
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)

    def test_get_log_out_without_being_logged_in(self):
        self.assertFalse(self._is_logged_in())
        response = self.client.get(self.url, follow=True)
        self.assertFalse(self._is_logged_in())
        redirect_url = reverse('log_in')
        self.assertRedirects(response, redirect_url, status_code=302, target_status_code=200)
