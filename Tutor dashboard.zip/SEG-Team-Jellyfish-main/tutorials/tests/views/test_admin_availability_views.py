"""Tests of the admin availability view."""
from django.test import TestCase
from django.urls import reverse
from tutorials.models import User, Tutor, Availability
from tutorials.forms import AdminAvailabilityForm, AvailabilityForm
from datetime import time

class AddAvailabilityViewTestCase(TestCase):
    """Tests of the add_admin_availability view."""

    fixtures = ['tutorials/tests/fixtures/default_user.json']

    def setUp(self):

        self.admin = User.objects.get(username='@johndoeT')
        self.tutor = User.objects.get(username='@janedoeT')
        self.tutor_profile = self.tutor.tutor_profile
        self.add_availability_url = reverse('add_admin_availability')
        self.admin_dashboard_url = reverse('admin_dashboard')

        self.valid_availability = {
            'tutor': self.tutor_profile.pk,
            'day': 'Friday',
            'start_time': time(13, 0),
            'end_time': time(14, 0),
        }
        self.invalid_availability = {
            'tutor': self.tutor_profile.pk,
            'day': 'Friday',
            'start_time': time(14, 0),
            'end_time': time(13, 0),
        }

        self.client.login(username=self.admin.username, password="Password123")

    def test_add_valid_availability(self):
        count_before = Availability.objects.count()
        response = self.client.post(self.add_availability_url, self.valid_availability, follow=True)
        self.assertRedirects(response, self.admin_dashboard_url)
        self.assertEqual(Availability.objects.count(), count_before + 1)

    def test_invalid_availability(self):
        count_before = Availability.objects.count()
        response = self.client.post(self.add_availability_url, self.invalid_availability, follow=True)
        self.assertEqual(Availability.objects.count(), count_before)
        self.assertContains(response, "Availability invalid: end_time must be after start_time")

    def test_add_overlapping_availability(self):
        overlapping_availability = Availability.objects.create(
            tutor=self.tutor_profile,
            day= 'Friday',
            start_time= time(13, 0),
            end_time= time(14, 0),
        )
        count_before = Availability.objects.count()
        response = self.client.post(self.add_availability_url, self.valid_availability, follow=True)
        self.assertEqual(Availability.objects.count(), count_before)
        self.assertRedirects(response, self.admin_dashboard_url)
        self.assertContains(response, "Availability overlaps with an existing Availability for this tutor")

    def test_non_post_request(self):
        response = self.client.get(self.add_availability_url)
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, self.admin_dashboard_url)