"""Tests of the tutor sign-up view."""
from django.test import TestCase
from django.urls import reverse
from tutorials.forms import TutorsSignUpForm
from tutorials.models import User

class TutorSignUpViewTestCase(TestCase):
    """Tests for the tutor sign-up view."""

    def setUp(self):
        self.url = reverse('sign_up_tutor')
        self.form_input = {
            'first_name': 'Jane',
            'last_name': 'Doe',
            'username': '@janedoeTTT',
            'email': 'janedoe.TT@example.org',
            'new_password': 'Password123',
            'password_confirmation': 'Password123',
            'subject': 'Maths',
        }

    def test_get_sign_up(self):
        """Test retrieving the tutor sign-up page."""
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'sign_up.html')
        form = response.context['form']
        self.assertIsInstance(form, TutorsSignUpForm)

    def test_successful_sign_up(self):
        """Test successful tutor sign-up."""
        before_count = User.objects.count()
        # print(f"[DEBUG] Users before tutor sign-up: {before_count}")
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = User.objects.count()
        # print(f"[DEBUG] Users after tutor sign-up: {after_count}")

        self.assertEqual(after_count, before_count + 1)
        self.assertRedirects(response, reverse('tutor_dashboard'))

        user = User.objects.get(username='@janedoeTTT')
        # print(f"[DEBUG] Created User: {user.username}, Email: {user.email}, Account Type: {user.account_type}")
        self.assertEqual(user.account_type, 'tutor')

    def test_unsuccessful_sign_up(self):
        """Test unsuccessful tutor sign-up due to invalid input."""
        self.form_input['username'] = ''  # Invalid username
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input)
        after_count = User.objects.count()

        self.assertEqual(after_count, before_count)  # No new user should be created
        self.assertTemplateUsed(response, 'sign_up.html')
        form = response.context['form']
        self.assertFalse(form.is_valid())
