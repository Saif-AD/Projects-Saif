from django.contrib.auth.hashers import check_password
from django.test import TestCase
from django.urls import reverse
from tutorials.forms import SignUpForm
from tutorials.models import User
from tutorials.tests.test_helpers import LogInTester

class SignUpViewTestCase(TestCase, LogInTester):
    fixtures = ['tutorials/tests/fixtures/default_user.json']

    def setUp(self):
        self.url = reverse('sign_up_student')
        self.form_input = {
            'first_name': 'Jane',
            'last_name': 'Doe',
            'username': '@janedoeTT',
            'email': 'janedoe.TT@example.org',
            'new_password': 'Password123',
            'password_confirmation': 'Password123',
        }
        self.invalid_form_input = {
            'first_name': 'Jane',
            'last_name': 'Doe',
            'username': '',
            'email': 'janedoe.TT@example.org',
            'new_password': 'Password123',
            'password_confirmation': 'Password123',
        }

    def _is_logged_in(self):
        return '_auth_user_id' in self.client.session

    def test_sign_up_url(self):
        self.assertEqual(self.url, '/sign_up/student')

    def test_get_sign_up(self):
        response = self.client.get(self.url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'sign_up.html')
        form = response.context['form']
        self.assertIsInstance(form, SignUpForm)
        self.assertFalse(form.is_bound)

    def test_successful_sign_up(self):
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input, follow=True)
        after_count = User.objects.count()

        self.assertEqual(after_count, before_count + 1)
        self.assertRedirects(response, reverse('student_dashboard'))
        self.assertTrue(self._is_logged_in())

        user = User.objects.get(username='@janedoeTT')
        self.assertEqual(user.account_type, 'student')

    def test_unsuccessful_sign_up(self):
        self.form_input['username'] = ''
        before_count = User.objects.count()
        response = self.client.post(self.url, self.form_input)
        after_count = User.objects.count()
        self.assertEqual(after_count, before_count)
        self.assertTemplateUsed(response, 'sign_up.html')
        form = response.context['form']
        self.assertTrue(form.is_bound)
        self.assertFalse(self._is_logged_in())

    def test_invalid_form_sign_up(self):
        response = self.client.post(self.url, self.invalid_form_input)
        form = response.context['form']
        self.assertTrue(form.errors)
        self.assertIn('This field is required.', form.errors.get('username'))

    def test_form_invalid_debug_output(self):
        response = self.client.post(self.url, self.invalid_form_input)
        form = response.context['form']
        self.assertIn("This field is required.", form.errors.get('username'))
