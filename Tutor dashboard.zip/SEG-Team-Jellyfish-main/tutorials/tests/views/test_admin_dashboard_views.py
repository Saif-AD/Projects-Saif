"""Tests of the admin dashboard view."""
from django.test import TestCase
from django.urls import reverse
from django.core.paginator import Paginator
from tutorials.models import User, Tutor, StudentRequest
from tutorials.forms import AdminLessonRequestForm, AdminAvailabilityForm

class AdminDashboardViewTestCase(TestCase):
    """Tests of the admin_dashboard view."""

    fixtures = ['tutorials/tests/fixtures/default_user.json']

    def setUp(self):

        self.admin = User.objects.get(username='@johndoeT')
        self.student = User.objects.get(username='@charlieT')

        self.add_availability_url = reverse('add_admin_availability')
        self.admin_dashboard_url = reverse('admin_dashboard')

        self.valid_student_request = {
            'student': self.student.id,
            'subject': 'Maths',
            'duration': '30m',
            'lesson_request': True,
        }
        self.invalid_student_request = {
            'student': self.student.id,
            'subject': 'Wrong',
            'duration': '30m',
            'lesson_request': True,
        }

        self.client.login(username=self.admin.username, password="Password123")

    def test_get_admin_dashboard(self):
        """Test GET request to the admin_dashboard view."""
        response = self.client.get(self.admin_dashboard_url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard.html')

        # Test context data
        self.assertIn('student_requests', response.context)
        self.assertIn('tutors', response.context)
        self.assertIn('students', response.context)
        self.assertIn('allocated_lessons', response.context)
        self.assertIn('admin_availability_form', response.context)
        self.assertIn('admin_request_form', response.context)
        tutor_page_obj = response.context['tutor_page_obj']
        student_page_obj = response.context['student_page_obj']
        self.assertEqual(tutor_page_obj.paginator.num_pages, 1)
        self.assertEqual(student_page_obj.paginator.num_pages, 1)

    def test_post_admin_dashboard_valid_form(self):
        """Test valid POST request to submit a new lesson request."""

        response = self.client.post(self.admin_dashboard_url, self.valid_student_request, follow=True)
        self.assertRedirects(response, self.admin_dashboard_url)
        self.assertEqual(StudentRequest.objects.count(), 1)
        new_request = StudentRequest.objects.last()
        self.assertEqual(new_request.student, self.student)
        self.assertEqual(new_request.subject, 'Maths')

    def test_post_admin_dashboard_invalid_form(self):
        """Test invalid POST request with invalid data."""

        response = self.client.post(self.admin_dashboard_url, self.invalid_student_request, follow=True)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'admin_dashboard.html')
        self.assertContains(response, 'Invalid form submission')
        self.assertEqual(StudentRequest.objects.count(), 0)