from django.urls import reverse
from django.test import Client

def reverse_with_next(url_name, next_url):
    url = reverse(url_name)
    return f"{url}?next={next_url}"

class LogInTester:
    def __init__(self, user):
        self.client = Client()
        self.user = user

    def login(self, password):
        return self.client.login(username=self.user.username, password=password)
    
class MenuTesterMixin:
    """
    Provides helper methods for testing menu rendering in templates.
    """
    def assertMenuContains(self, response, menu_item_text):
        """
        Check if the rendered response contains a specific menu item.
        """
        self.assertContains(response, menu_item_text)

    def assertMenuNotContains(self, response, menu_item_text):
        """
        Check if the rendered response does not contain a specific menu item.
        """
        self.assertNotContains(response, menu_item_text)
