from django.test import TestCase
from django.contrib.auth import get_user_model
from tutorials.models import Invoice
from django.utils.timezone import now, timedelta

User = get_user_model()

class InvoiceModelTest(TestCase):
    def setUp(self):
        self.student = User.objects.create_user(
            username='test_student',
            account_type='student',
            email='test_student@example.com',
            password='password123'
        )

    def test_invoice_creation(self):
        invoice = Invoice.objects.create(
            student=self.student,
            total_amount=150.00,
            due_date=now().date() + timedelta(days=7)
        )
        self.assertEqual(invoice.status, 'unpaid')
        self.assertFalse(invoice.is_overdue())

    def test_mark_as_paid(self):
        invoice = Invoice.objects.create(
            student=self.student,
            total_amount=150.00,
            due_date=now().date() + timedelta(days=7)
        )
        invoice.mark_as_paid()
        self.assertEqual(invoice.status, 'paid')
