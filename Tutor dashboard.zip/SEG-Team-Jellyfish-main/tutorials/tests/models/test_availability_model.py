from django.core.exceptions import ValidationError
from django.test import TestCase
from tutorials.models import Tutor, Availability
from django.contrib.auth import get_user_model
User = get_user_model()
from datetime import time

class AvailabilityModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create(username='test_tutor', first_name='John', last_name='Doe')
        self.tutor = Tutor.objects.create(user=self.user, subject="Math")

    def test_create_availability_slot(self):
        availability = Availability.objects.create(
            tutor=self.tutor,
            day="Monday",
            start_time=time(9, 0),
            end_time=time(11, 0)
        )
        self.assertEqual(availability.tutor, self.tutor)
        self.assertEqual(availability.day, "Monday")
        self.assertEqual(availability.start_time, time(9, 0))

    def test_non_overlapping_availability_slots(self):
        Availability.objects.create(
            tutor=self.tutor,
            day="Monday",
            start_time=time(9, 0),
            end_time=time(11, 0)
        )
        non_overlapping_availability = Availability(
            tutor=self.tutor,
            day="Monday",
            start_time=time(11, 30),
            end_time=time(13, 0)
        )
        non_overlapping_availability.full_clean()