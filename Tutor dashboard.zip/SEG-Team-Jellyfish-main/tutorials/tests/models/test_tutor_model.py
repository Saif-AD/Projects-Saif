from django.core.exceptions import ValidationError
from django.test import TestCase
from django.contrib.auth import get_user_model
from tutorials.models import Tutor, Availability

User = get_user_model()

class TutorModelTest(TestCase):
    def setUp(self):
        self.user = User.objects.create(username='testuser', first_name='John', last_name='Doe')
        self.tutor = Tutor.objects.create(user=self.user, subject="Python")
        Availability.objects.create(tutor=self.tutor, day="Monday", start_time="10:00", end_time="12:00")

    def test_tutor_creation(self):
        self.assertEqual(self.tutor.user.username, "testuser")
        self.assertEqual(self.tutor.subject, "Python")
        self.assertEqual(str(self.tutor), 'testuser')

    def test_tutor_subject_not_blank(self):
        empty_subject_tutor = Tutor(user=self.user, subject="")
        with self.assertRaises(ValidationError):
            empty_subject_tutor.full_clean()

    def test_tutor_availability(self):
        availability = self.tutor.availability.first() 
        self.assertEqual(availability.day, "Monday")
        self.assertEqual(str(availability.start_time), "10:00:00")
        self.assertEqual(str(availability.end_time), "12:00:00")
