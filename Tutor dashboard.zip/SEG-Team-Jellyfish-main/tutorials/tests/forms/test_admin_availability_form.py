"""Unit tests of the Availability form."""
from django import forms
from django.test import TestCase
from tutorials.forms import AdminAvailabilityForm
from tutorials.models import Availability, Tutor, User
from datetime import time

class AdminAvailabilityFormTestCase(TestCase):
    """Unit tests of the availability form."""

    fixtures = [
        'tutorials/tests/fixtures/default_user.json'
    ]

    def setUp(self):
        self.user = User.objects.get(username='@janedoeT')
        self.tutor = self.user.tutor_profile
        self.valid_input = {
            'tutor' : self.tutor,
            'day': 'Friday',
            'start_time': time(13, 0),
            'end_time': time(14, 0),
        }
        self.invalid_input = {
            'tutor' : self.tutor,
            'day': 'Friday',
            'start_time': time(14, 0),
            'end_time': time(13, 0),
        }

    def test_form_has_necessary_fields(self):
        form = AdminAvailabilityForm()
        self.assertIn('tutor', form.fields)
        self.assertIn('day', form.fields)
        self.assertIn('start_time', form.fields)
        self.assertIn('end_time', form.fields)

    def test_valid_form(self):
        form = AdminAvailabilityForm(data=self.valid_input)
        self.assertTrue(form.is_valid())

    def test_invalid_form_end_time_before_start_time(self):
        form = AdminAvailabilityForm(data=self.invalid_input)
        self.assertFalse(form.is_valid())