"""Unit tests of the Availability form."""
from django import forms
from django.test import TestCase
from tutorials.forms import AvailabilityForm
from tutorials.models import Availability
from datetime import time

class AvailabilityFormTestCase(TestCase):
    """Unit tests of the availability form."""

    def setUp(self):
        self.valid_input = {
            'day': 'Friday',
            'start_time': time(13, 0),
            'end_time': time(14, 0),
        }
        self.invalid_input = {
            'day': 'Friday',
            'start_time': time(14, 0),
            'end_time': time(13, 0),
        }

    def test_form_has_necessary_fields(self):
        form = AvailabilityForm()
        self.assertIn('day', form.fields)
        self.assertIn('start_time', form.fields)
        self.assertIn('end_time', form.fields)

    def test_valid_form(self):
        form = AvailabilityForm(data=self.valid_input)
        self.assertTrue(form.is_valid())

    def test_invalid_form_end_time_before_start_time(self):
        form = AvailabilityForm(data=self.invalid_input)
        self.assertFalse(form.is_valid())