"""Forms for the tutorials app."""
from django import forms
from django.contrib.auth import authenticate
from django.core.validators import RegexValidator
from .models import User, Tutor, Availability, StudentRequest, Invoice, AllocatedLessons

class LogInForm(forms.Form):
    """Form enabling registered users to log in."""

    username = forms.CharField(label="Username")
    password = forms.CharField(label="Password", widget=forms.PasswordInput())

    def get_user(self):
        """Returns authenticated user if possible."""

        user = None
        if self.is_valid():
            username = self.cleaned_data.get('username')
            password = self.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
        return user


class UserForm(forms.ModelForm):
    """Form to update user profiles."""

    class Meta:
        """Form options."""

        model = User
        fields = ['first_name', 'last_name', 'username', 'email']

class NewPasswordMixin(forms.Form):
    """Form mixing for new_password and password_confirmation fields."""

    new_password = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(),
        validators=[RegexValidator(
            regex=r'^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).*$',
            message='Password must contain an uppercase character, a lowercase '
                    'character and a number'
            )]
    )
    password_confirmation = forms.CharField(label='Password confirmation', widget=forms.PasswordInput())

    def clean(self):
        """Form mixing for new_password and password_confirmation fields."""

        cleaned_data = super().clean()
        new_password = self.cleaned_data.get('new_password')
        password_confirmation = self.cleaned_data.get('password_confirmation')
        if new_password != password_confirmation:
            self.add_error('password_confirmation', 'Confirmation does not match password.')
        return cleaned_data


class PasswordForm(NewPasswordMixin):
    """Form enabling users to change their password."""

    password = forms.CharField(label='Current password', widget=forms.PasswordInput())

    def __init__(self, user=None, **kwargs):
        """Construct new form instance with a user instance."""
        
        super().__init__(**kwargs)
        self.user = user

    def clean(self):
        """Clean the data and generate messages for any errors."""

        super().clean()
        password = self.cleaned_data.get('password')
        if self.user is not None:
            user = authenticate(username=self.user.username, password=password)
        else:
            user = None
        if user is None:
            self.add_error('password', "Password is invalid")

    def save(self, commit=True):
        """Save the user's new password."""
        new_password = self.cleaned_data['new_password']
        if self.user is not None:
            self.user.set_password(new_password)
            if commit:
                self.user.save()
        return self.user

class SignUpForm(NewPasswordMixin, forms.ModelForm):
    """Form enabling unregistered users to sign up."""
    new_password = forms.CharField(
        widget=forms.PasswordInput,
        label="Password",
        required=True,
    )
    password_confirmation = forms.CharField(
        widget=forms.PasswordInput,
        label="Password confirmation",
        required=True,
    )

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'email']

    def clean(self):
        """Ensure password and confirmation match and enforce constraints."""
        cleaned_data = super().clean() or {}

        new_password = cleaned_data.get('new_password')
        password_confirmation = cleaned_data.get('password_confirmation')


        if new_password and password_confirmation and new_password != password_confirmation:
            self.add_error('password_confirmation', 'Passwords do not match.')

        if new_password:
            if not any(char.islower() for char in new_password):
                self.add_error('new_password', 'Password must contain at least one lowercase character.')
            if not any(char.isupper() for char in new_password):
                self.add_error('new_password', 'Password must contain at least one uppercase character.')
            if not any(char.isdigit() for char in new_password):
                self.add_error('new_password', 'Password must contain at least one digit.')

        return cleaned_data

    def save(self, commit=True):
        """Save user with hashed password."""
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['new_password'])
        user.account_type = 'student'
        if commit:
            user.save()
        return user

class TutorsSignUpForm(SignUpForm):
    """ This is form for tutors with additional field subject """
    SUBJECT_CHOICES = [
        ('Physics', 'physics'),
        ('Maths', 'maths'),
        ('Chemistry', 'chemistry'),
        ("Biology", 'biology'),
        ('Economics', 'economics'),
        ('History', 'history'),
        ('Geography', 'geography')
    ]

    subject = forms.ChoiceField(choices=SUBJECT_CHOICES, label="Subject")

    class Meta(SignUpForm.Meta):
        """Form options, inheriting from SignUpForm."""
        fields = SignUpForm.Meta.fields + ['subject']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['new_password'])
        user.account_type = 'tutor' 
        if commit:
            user.save()

            Tutor.objects.create(user=user, subject=self.cleaned_data['subject'])
        return user


class AvailabilityForm(forms.ModelForm):
    """Form for creating and updating availabilities"""

    class Meta:
        model = Availability
        fields = ['day', 'start_time', 'end_time']

        # Styling
        widgets = {
            'day': forms.Select(attrs={
                'class': 'form-select',
            }),
            'start_time': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time',
            }),
            'end_time': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time',
            }),
        }

    def clean(self):
        cleaned_data = super().clean()
        start_time = cleaned_data.get('start_time')
        end_time = cleaned_data.get('end_time')

        if start_time and end_time and end_time <= start_time:
            raise forms.ValidationError("End time must be after start time.")

class AdminAvailabilityForm(forms.ModelForm):
    """Form for admin creating and updating tutors' availabilities"""

    tutor = forms.ModelChoiceField(
        queryset=Tutor.objects.all().order_by('user__username'),
        required=True,
        label="Select Tutor",
        widget = forms.Select(attrs={'class': 'form-select'}) # Styling
    )

    class Meta:
        model = Availability
        fields = ['tutor', 'day', 'start_time', 'end_time']

        # Styling
        widgets = {
            'day': forms.Select(attrs={'class': 'form-select'}),
            'start_time': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time',
            }),
            'end_time': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time',
            }),
        }

    def clean(self):
        cleaned_data = super().clean()
        start_time = cleaned_data.get('start_time')
        end_time = cleaned_data.get('end_time')

        if start_time and end_time and end_time <= start_time:
            raise forms.ValidationError("End time must be after start time.")

class StudentRequestForm(forms.ModelForm):
    """Form for creating and updating student requests"""

    DURATION_CHOICES = [
        ('15m', '15m'),
        ('30m', '30m'),
        ('1h', '1h'),
        ('2h', '2h'),
    ]

    duration = forms.ChoiceField(
        choices=DURATION_CHOICES,
        widget=forms.Select
    )
    
    SUBJECT_CHOICES = [
        ('Physics', 'physics'),
        ('Maths', 'maths'),
        ('Chemistry', 'chemistry'),
        ("Biology", 'biology'),
        ('Economics', 'economics'),
        ('History', 'history'),
        ('Geography', 'geography')
    ]

    subject = forms.ChoiceField(choices=SUBJECT_CHOICES, label="Subject")     

    class Meta:
        model = StudentRequest
        fields = ['subject', 'duration']
        widgets = {
            'subject': forms.Select(attrs={'class': 'form-select'}),
            'duration': forms.Select(attrs={'class': 'form-select'}),
        }

class AdminLessonRequestForm(forms.ModelForm):
    """Form for admin creating and updating student requests"""

    student = forms.ModelChoiceField(
        queryset=User.objects.filter(account_type='student').order_by('username'),
        required=True,
        label="Select Student",
        widget = forms.Select(attrs={'class': 'form-select'}) # Styling
    )

    class Meta:
        model = StudentRequest
        fields = ['student', 'subject', 'duration']

        # Styling
        widgets = {
            'subject': forms.Select(attrs={'class': 'form-select'}),
            'duration': forms.Select(attrs={'class': 'form-select'}),
        }

class InvoiceForm(forms.ModelForm):
    """Form for creating and updating invoices."""

    class Meta:
        model = Invoice
        fields = ['due_date', 'total_amount', 'status']
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date'}),
            'total_amount': forms.NumberInput(attrs={'step': '0.01'}),
        }

class AllocatedLessonsForm(forms.ModelForm):
    class Meta:
        model = AllocatedLessons
        fields = ['tutor', 'student', 'subject', 'day_of_week', 'start_time', 'end_time']