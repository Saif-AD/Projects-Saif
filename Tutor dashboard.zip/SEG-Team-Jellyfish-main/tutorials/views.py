from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import ImproperlyConfigured
from django.shortcuts import redirect, render, get_object_or_404
from django.http import Http404, HttpResponseForbidden
from django.views import View
from django.views.generic.edit import FormView, UpdateView, CreateView, DeleteView
from django.views.generic import ListView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponse, HttpResponseRedirect
from tutorials.forms import LogInForm, PasswordForm, UserForm, SignUpForm, AvailabilityForm, AdminAvailabilityForm, StudentRequestForm, AdminLessonRequestForm, TutorsSignUpForm, InvoiceForm, AllocatedLessonsForm
from tutorials.models import Tutor, Availability, StudentRequest, Invoice, AllocatedLessons, User
from tutorials.helpers import login_prohibited
from datetime import datetime, timedelta
from django.utils.timezone import now
from django.db.models import Q, Exists, OuterRef
from django.core.paginator import Paginator

@login_required
def dashboard(request):
    """Display the current user's dashboard."""
    # Different Dashboard for Admin, Student and Tutor
    current_user = request.user
    account_type = current_user.account_type

    # Handle Student Redirect after log_in
    if account_type=='student':
        invoices = Invoice.objects.filter(student=request.user)
        allocated_lessons = AllocatedLessons.objects.filter(student=request.user)
        requests = StudentRequest.objects.filter(student=request.user).order_by('-date_requested')
        form = StudentRequestForm()
        return render(request, 'student_dashboard.html', {'form': form, 'requests': requests, 'user': current_user,
                                        'invoices': invoices, 'allocated_lessons': allocated_lessons})
    # Tutor Redirect
    elif account_type=='tutor':
        return redirect('tutor_dashboard')
    # Admin Redirect
    elif account_type=='admin':
        return admin_dashboard(request)


@login_prohibited
def home(request):
    """Display the application's start/home screen."""
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'home.html')

def home_view(request):
    if request.user.is_authenticated:
        return redirect('student_dashboard')
    return render(request, 'home.html')


class LoginProhibitedMixin:
    """Mixin that redirects when a user is logged in."""

    redirect_when_logged_in_url = None

    def dispatch(self, *args, **kwargs):
        """Redirect when logged in, or dispatch as normal otherwise."""
        if self.request.user.is_authenticated:
            return self.handle_already_logged_in(*args, **kwargs)
        return super().dispatch(*args, **kwargs)

    def handle_already_logged_in(self, *args, **kwargs):
        url = self.get_redirect_when_logged_in_url()
        return redirect(url)

    def get_redirect_when_logged_in_url(self):
        """Returns the url to redirect to when not logged in."""
        if self.redirect_when_logged_in_url is None:
            raise ImproperlyConfigured(
                "LoginProhibitedMixin requires either a value for "
                "'redirect_when_logged_in_url', or an implementation for "
                "'get_redirect_when_logged_in_url()'."
            )
        else:
            return self.redirect_when_logged_in_url


class LogInView(LoginProhibitedMixin, View):
    """Display login screen and handle user login."""

    http_method_names = ['get', 'post']
    redirect_when_logged_in_url = settings.REDIRECT_URL_WHEN_LOGGED_IN

    def get(self, request):
        """Display log in template."""

        self.next = request.GET.get('next') or ''
        return self.render()

    def post(self, request):
        """Handle log in attempt."""

        form = LogInForm(request.POST)
        self.next = request.POST.get('next') or settings.REDIRECT_URL_WHEN_LOGGED_IN
        user = form.get_user()
        if user is not None:
            login(request, user)
            return redirect(self.next)
        messages.add_message(request, messages.ERROR, "The credentials provided were invalid!")
        return self.render()

    def render(self):
        """Render log in template with blank log in form."""

        form = LogInForm()
        return render(self.request, 'log_in.html', {'form': form, 'next': self.next})


def log_out(request):
    """Log out the current user"""

    logout(request)
    return redirect(reverse('log_in'))


class PasswordView(LoginRequiredMixin, FormView):
    """Display password change screen and handle password change requests."""

    template_name = 'password.html'
    form_class = PasswordForm

    def get_form_kwargs(self, **kwargs):
        """Pass the current user to the password change form."""

        kwargs = super().get_form_kwargs(**kwargs)
        kwargs.update({'user': self.request.user})
        return kwargs

    def form_valid(self, form):
        """Handle valid form by saving the new password."""
        self.object = form.save(commit=True)
        login(self.request, self.object)
        return super().form_valid(form)

    def get_success_url(self):
        """Redirect the user after successful password change."""

        messages.add_message(self.request, messages.SUCCESS, "Password updated!")
        return reverse('dashboard')


class ProfileUpdateView(LoginRequiredMixin, UpdateView):
    """Display user profile editing screen, and handle profile modifications."""

    model = UserForm
    template_name = "profile.html"
    form_class = UserForm

    def get_object(self):
        """Return the object (user) to be updated."""
        user = self.request.user
        return user

    def get_success_url(self):
        """Return redirect URL after successful update."""
        messages.add_message(self.request, messages.SUCCESS, "Profile updated!")
        return reverse(settings.REDIRECT_URL_WHEN_LOGGED_IN)

class SignUpView(LoginProhibitedMixin, FormView):
    """Display the student sign-up screen and handle sign-ups."""
    form_class = SignUpForm
    template_name = "sign_up.html"
    redirect_when_logged_in_url = 'student_dashboard'

    def form_valid(self, form):
        self.object = form.save(commit=True)
        login(self.request, self.object)
        return super().form_valid(form)

    def get_success_url(self):
        """Redirect to student dashboard after successful sign-up."""
        return reverse('student_dashboard')


class TutorSignUpView(LoginProhibitedMixin, FormView):
    """Display the tutor sign-up screen and handle sign-ups."""
    form_class = TutorsSignUpForm
    template_name = "sign_up.html"
    redirect_when_logged_in_url = 'tutor_dashboard'

    def form_valid(self, form):
        self.object = form.save(commit=True)

        login(self.request, self.object)
        return super().form_valid(form)


    def get_success_url(self):
        """Redirect to tutor dashboard after successful sign-up."""
        return reverse('tutor_dashboard')

@login_required
def add_availability(request):
    """Create availability to be used by tutors"""

    current_user = request.user
    tutor = current_user.tutor_profile

    if request.method == 'POST':
        form = AvailabilityForm(request.POST)
        if form.is_valid():
            try:
                availability = form.save(commit=False)
                availability.tutor = tutor

                # check if this availability overlaps with another existing availability
                overlap_availabilities = Availability.objects.filter(tutor= tutor)

                for avail in overlap_availabilities:
                    if avail.day == availability.day:
                        if (avail.start_time <= availability.start_time < avail.end_time or
                                    avail.start_time < availability.end_time <= avail.end_time):
                            messages.error(request, "Availability overlaps with another Availability you have registered!")
                            availability.save()
                            availability.delete()
                            return redirect('tutor_dashboard')

                availability.save()
            except:
                form.add_error(None, "Could not add this availability")
            else:
                messages.success(request, "Availability added successfully!")
        else:
            messages.error(request, "Availability invalid: end_time must be after start_time")

    # if GET request: it will be handled by tutor_dashboard

    return redirect('tutor_dashboard')


@login_required
def add_admin_availability(request):
    """Admin create availability to be assigned to a tutor"""

    if request.method == 'POST':
        form = AdminAvailabilityForm(request.POST)
        if form.is_valid():
            try:
                availability = form.save(commit=False)
                tutor = form.cleaned_data['tutor']
                availability.tutor = tutor

                # check if this availability overlaps with another existing availability
                overlap_availabilities = Availability.objects.filter(tutor=tutor)

                for avail in overlap_availabilities:
                    if avail.day == availability.day:
                        if (avail.start_time <= availability.start_time < avail.end_time or
                                    avail.start_time < availability.end_time <= avail.end_time):
                            messages.error(request, "Availability overlaps with an existing Availability for this tutor")
                            availability.save()
                            availability.delete()
                            return redirect('admin_dashboard')

                availability.save()
            except:
                form.add_error(None, "Could not add this availability")
            else:
                messages.success(request, "Availability added successfully!")
                path = reverse('admin_dashboard')
                return HttpResponseRedirect(path)
        else:
            messages.error(request, "Availability invalid: end_time must be after start_time")

    # if GET request: it will be handled by admin_dashboard

    return redirect('admin_dashboard')

def admin_dashboard(request):
    # Fetch all unallocated student requests
    student_requests = StudentRequest.objects.filter(allocation__isnull=True).order_by('-date_requested')

    # Fetch all tutors to be used in the context
    all_tutors = Tutor.objects.all().order_by('user__username')
    # Fetch all the students
    all_students = User.objects.filter(account_type='student').order_by('username')
    # Paginators
    tutor_paginator = Paginator(all_tutors, 5)  # 5 tutors per page
    student_paginator = Paginator(all_students, 5)  # 5 students per page
    # Get the paginated objects
    tutor_page_number = request.GET.get('tutor_page', 1)
    student_page_number = request.GET.get('student_page', 1)
    tutor_page_obj = tutor_paginator.get_page(tutor_page_number)
    student_page_obj = student_paginator.get_page(student_page_number)

    # Fetch all the allocated lessons that the date is not yet passed
    all_allocated_lessons = AllocatedLessons.objects.all()

    # Initialize
    selected_request_id = None
    available_days = []
    available_times = []
    selected_tutor_id = None
    selected_day = None

    if request.method == 'POST':
        selected_request_id = request.POST.get('request_id')
        selected_tutor_id = request.POST.get('tutor_id')
        selected_day = request.POST.get('day')

        # Check which form was submitted
        if 'lesson_request' in request.POST:
            form = AdminLessonRequestForm(request.POST)
            if form.is_valid():
                # Save form directly since ModelForm handles validation
                instance = form.save(commit=False)
                instance.student = form.cleaned_data['student']
                instance.save()
                return redirect('admin_dashboard')
            else:
                messages.error(request, 'Invalid form submission')
            
            return redirect('admin_dashboard')

        # If Allocate Button is pressed
        elif 'allocate_lesson' in request.POST:  # Form name for lesson allocation
            time = request.POST.get('time')
            
            if selected_request_id and selected_tutor_id and selected_day and time:
                student_request = get_object_or_404(StudentRequest, id=selected_request_id)
                tutor = get_object_or_404(Tutor, id=selected_tutor_id)
                
                lesson_duration = parse_duration(student_request.duration)  # Lesson duration from StudentRequest
                start_time = datetime.strptime(time, "%H:%M").time()
                end_time = (datetime.combine(datetime.today(), start_time) + timedelta(minutes=lesson_duration)).time()

                # Create the allocated lesson
                AllocatedLessons.objects.create(
                    tutor=tutor,
                    student=student_request.student,
                    subject=student_request.subject,
                    day_of_week=selected_day,
                    start_time=start_time,
                    end_time=end_time
                )

                # Remove the student request since the lesson has been allocated
                student_request.delete()

                return redirect('admin_dashboard')
        
        # If a tutor was selected, load the available days
        elif selected_tutor_id:
            available_days = Availability.objects.filter(tutor_id=selected_tutor_id).values_list('day', flat=True).distinct()
        
        # If a tutor and day were selected, calculate available time slots
        if selected_tutor_id and selected_day:
            student_request = get_object_or_404(StudentRequest, id=selected_request_id)
            lesson_duration = parse_duration(student_request.duration)  # Duration from the StudentRequest

            # Get the tutor's availability for the selected day
            tutor_availabilities = Availability.objects.filter(tutor_id=selected_tutor_id, day=selected_day)

            # Split availability into time slots
            for availability in tutor_availabilities:
                start_time = availability.start_time
                end_time = availability.end_time

                current_time = datetime.combine(datetime.today(), start_time)
                end_time_datetime = datetime.combine(datetime.today(), end_time)

                while current_time + timedelta(minutes=lesson_duration) <= end_time_datetime:
                    available_times.append(current_time.time().strftime("%H:%M"))
                    current_time += timedelta(minutes=lesson_duration)

            # Remove already allocated lessons
            allocated_lessons = AllocatedLessons.objects.filter(tutor_id=selected_tutor_id, day_of_week=selected_day)
            for lesson in allocated_lessons:
                lesson_start = datetime.combine(datetime.today(), lesson.start_time)
                lesson_end = datetime.combine(datetime.today(), lesson.end_time)

                # Exclude overlapping time slots
                available_times = [
                    slot for slot in available_times
                    if not (lesson_start.time() <= datetime.strptime(slot, "%H:%M").time() < lesson_end.time())
                ]


            for lesson in allocated_lessons:
                lesson_start = lesson.start_time  # Directly access the time field
                lesson_end = lesson.end_time  # Directly access the time field

                # Remove time slots that fall within the allocated lesson
                available_times = [
                    time_slot for time_slot in available_times 
                    if not (lesson_start <= datetime.strptime(time_slot, "%H:%M").time() < lesson_end)
                ]

    # Forms for GET requests
    admin_availability_form = AdminAvailabilityForm()
    admin_request_form = AdminLessonRequestForm()

    context = {
        'student_requests': student_requests,
        'tutors': all_tutors,
        'students': all_students,
        'tutor_page_obj': tutor_page_obj,
        'student_page_obj': student_page_obj,
        'admin_availability_form': admin_availability_form,
        'admin_request_form': admin_request_form,
        'allocated_lessons': all_allocated_lessons,
        'available_days': available_days,
        'available_times': available_times,
        'selected_request_id': selected_request_id,
        'selected_tutor_id': selected_tutor_id,
        'selected_day': selected_day
    }

    return render(request, 'admin_dashboard.html', context)

def parse_duration(duration_str):
    # Convert Duration String into int
    if 'm' in duration_str:
        return int(duration_str.replace('m', ''))  # Convert '15m' to 15
    elif 'h' in duration_str:
        return int(duration_str.replace('h', '')) * 60  # Convert '1h' to 60
    else:
        raise ValueError(f"Invalid duration format: {duration_str}")

@login_required
def inspect_tutor(request, tutor_id):
    """Admin inspect tutor dashboard button"""

    try:
        tutor = Tutor.objects.get(id=tutor_id)

        if request.method == "POST":
            availabilities = Availability.objects.filter(tutor=tutor).order_by('day', 'start_time')
            invoices = Invoice.objects.filter(tutor=tutor.user)
            allocated_lessons = AllocatedLessons.objects.filter(tutor=tutor)
            return render(request, 'tutor_dashboard_as_admin.html', {'tutorToInspect': tutor,
                    'invoices': invoices, 'availabilities': availabilities, 'allocated_lessons': allocated_lessons})

    except Tutor.DoesNotExist:
        raise Http404(f"Could not find tutor with primary key {tutor_id}")

    return render(request, 'admin_dashboard.html')

@login_required
def inspect_student(request, student_id):
    """Admin inspect student dashboard button"""

    try:
        student = User.objects.get(id=student_id)

        if request.method == "POST":
            requests = StudentRequest.objects.filter(student=student)
            invoices = Invoice.objects.filter(student=student)
            allocated_lessons = AllocatedLessons.objects.filter(student=student)
            return render(request, 'student_dashboard_as_admin.html', {'studentToInspect': student,
                'invoices': invoices,'requests': requests, 'allocated_lessons': allocated_lessons})

    except User.DoesNotExist:
        raise Http404(f"Could not find student with primary key {student_id}")

    return render(request, 'admin_dashboard.html')

@login_required
def delete_availability(request, availability_id):
    """Delete availability to be used by tutors"""

    current_user = request.user
    tutor = current_user.tutor_profile

    try:
        availability = Availability.objects.get(id=availability_id)
    except Availability.DoesNotExist:
        raise Http404(f"Could not find availability with primary key {availability_id}")

    # Ensure that the availability belongs to the current tutor.
    if availability.tutor != tutor:
        return HttpResponseForbidden("This availability does not belong to you.")

    if request.method == "POST":
        availability.delete()

    return redirect('tutor_dashboard')



class studentRequestCreateView(LoginRequiredMixin, CreateView):
    model = StudentRequest
    #template_name = "#"
    form_class = StudentRequestForm

    def form_valid(self, form):
        # Attach the logged-in user to the request
        form.instance.student = self.request.user
        form.save()
        return redirect(self.get_success_url())

    def get_success_url(self):
        # Redirect the user to their dashboard or other page
        return reverse_lazy('dashboard')

@login_required
def delete_request(request, pk):
    # Fetch the request object
    student_request = get_object_or_404(StudentRequest, pk=pk)

    # Ensure the request belongs to the logged-in student
    if student_request.student != request.user:
        return HttpResponseForbidden("You are not allowed to delete this request.")

    # Delete the request
    student_request.delete()
    return redirect('dashboard')  # Redirect back to the dashboard

# Loads student_dashboard with needed context
def student_dashboard(request):
    invoices = Invoice.objects.filter(student=request.user)
    allocated_lessons = AllocatedLessons.objects.filter(student=request.user)
    requests = StudentRequest.objects.filter(student=request.user).order_by('-date_requested')
    form = StudentRequestForm()
    return render(request, 'student_dashboard.html', {'invoices': invoices, 'form': form,
                            'allocated_lessons': allocated_lessons, 'requests': requests})

def lesson_requests(request):
    return render(request, 'lesson_requests.html')

# Loads tutor_dashboard with needed context
def tutor_dashboard(request):
    availabilities = Availability.objects.filter(tutor= request.user.tutor_profile).order_by('day', 'start_time')
    invoices = Invoice.objects.filter(tutor=request.user)
    allocated_lessons = AllocatedLessons.objects.filter(tutor=request.user.tutor_profile)
    availability_form = AvailabilityForm()
    return render(request, 'tutor_dashboard.html', {'availability_form': availability_form, 'invoices': invoices,
                'availabilities': availabilities, 'allocated_lessons': allocated_lessons})


class InvoiceListView(LoginRequiredMixin, ListView):
    """View to list all invoices."""
    model = Invoice
    template_name = "invoice_list.html"
    context_object_name = "invoices"
    paginate_by = 10

    def get_queryset(self):
        """Filter invoices to show only those related to the logged-in user."""
        return Invoice.objects.filter(student=self.request.user)

class InvoiceCreateView(LoginRequiredMixin, CreateView):
    """View to create a new invoice."""
    model = Invoice
    form_class = InvoiceForm
    template_name = "invoice_form.html"

    def form_valid(self, form):
        """Assign the logged-in user as the student for the invoice."""
        form.instance.student = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('invoice_list')

class InvoiceUpdateView(LoginRequiredMixin, UpdateView):
    """View to update an existing invoice."""
    model = Invoice
    form_class = InvoiceForm
    template_name = "invoice_form.html"

    def get_success_url(self):
        return reverse_lazy('invoice_list')

class InvoiceDeleteView(LoginRequiredMixin, DeleteView):
    """View to delete an invoice."""
    model = Invoice
    template_name = "invoice_confirm_delete.html"

    def get_success_url(self):
        return reverse_lazy('invoice_list')
    


class AllocatedLessonListView(LoginRequiredMixin, ListView):
    """View to list all allocated lessons."""
    model = AllocatedLessons
    template_name = "allocated_lesson_list.html"
    context_object_name = "allocated_lessons"
    paginate_by = 10

    def get_queryset(self):
        current_user = self.request.user
        account_type = current_user.account_type
        """Filter allocated lessons to show only those related to the logged-in user."""
        if account_type=='student':
            return AllocatedLessons.objects.filter(student=self.request.user)
        elif account_type=='tutor':
            return AllocatedLessons.objects.filter(tutor=self.request.user) 

class AllocatedLessonCreateView(LoginRequiredMixin, CreateView):
    """View to create a new allocated lesson."""
    model = AllocatedLessons
    form_class = AllocatedLessonsForm
    template_name = "allocated_lesson_form.html"

    def form_valid(self, form):
        """Assign the logged-in user as the tutor for the allocated lesson."""
        form.instance.tutor = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('allocated_lesson_list')

class AllocatedLessonDeleteView(LoginRequiredMixin, DeleteView):
    """View to delete an allocated lesson."""
    model = AllocatedLessons
    template_name = "allocated_lesson_confirm_delete.html"

    def get_success_url(self):
        return reverse_lazy('dashboard')