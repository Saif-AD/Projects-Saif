from django.contrib import admin
from django.contrib.auth.admin import UserAdmin 

from .models import User, StudentRequest, Tutor, Availability, Invoice, AllocatedLessons
# Register your models here.

admin.site.register(User)
admin.site.register(StudentRequest)
admin.site.register(Tutor)
admin.site.register(Availability)
admin.site.register(AllocatedLessons)

class InvoiceAdmin(admin.ModelAdmin):
    list_display = ('id', 'student', 'issued_date', 'due_date', 'total_amount', 'status')
    list_filter = ('status', 'issued_date', 'due_date')
    search_fields = ('student__username', 'id')