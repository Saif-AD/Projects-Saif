"""
URL configuration for code_tutors project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from tutorials import views
from django.contrib.auth.views import LoginView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('log_in/', views.LogInView.as_view(), name='log_in'),
    path('log_out/', views.log_out, name='log_out'),
    path('password/', views.PasswordView.as_view(), name='password'),
    path('profile/', views.ProfileUpdateView.as_view(), name='profile'),
    path('sign_up/student', views.SignUpView.as_view(), name='sign_up_student'),
    path('sign_up/tutor', views.TutorSignUpView.as_view(), name='sign_up_tutor'),
    path('tutor_dashboard/add/', views.add_availability, name='add_availability'),
    path('tutor_dashboard/delete/<int:availability_id>', views.delete_availability, name='delete_availability'),
    path('dashboard/studentRequest/', views.studentRequestCreateView.as_view(), name='student_request'),
    path('admin_dashboard/add/', views.add_admin_availability, name='add_admin_availability'),
    path('admin_dashboard/inspect_tutor/<int:tutor_id>', views.inspect_tutor, name='inspect_tutor'),
    path('admin_dashboard/inspect_student/<int:student_id>', views.inspect_student, name='inspect_student'),

    #Just for Testing
    path('student_dashboard/', views.student_dashboard, name='student_dashboard'),
    path('lesson_requests/', views.lesson_requests, name='lesson_requests'),
    path('tutor_dashboard/', views.tutor_dashboard, name='tutor_dashboard'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),

    path('request_lesson/', views.studentRequestCreateView.as_view(), name='student_request_create'),
    path('reuqest/<int:pk>/delete', views.delete_request, name='delete_request'),
    path('allocated_lesson/delete/<int:pk>/', views.AllocatedLessonDeleteView.as_view(), name='allocated_lesson_delete'),
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)