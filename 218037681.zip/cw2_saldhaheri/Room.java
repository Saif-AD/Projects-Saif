import java.util.Set;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Random;

/**
 * Class Room - a room in an adventure game.
 *
 * This class is part of the "World of Zuul" application. 
 * "World of Zuul" is a very simple, text based adventure game.  
 *
 * A "Room" represents one location in the scenery of the game.  It is 
 * connected to other rooms via exits.  For each existing exit, the room 
 * stores a reference to the neighboring room.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class Room 
{
    private String description;
    private HashMap<String, Room> exits;        // stores exits of this room.
    private HashMap<String, Item> items;  // New attribute to store items
    private HashMap<String, Character> characters;

    /**
     * Create a room described "description". Initially, it has
     * no exits. "description" is something like "a kitchen" or
     * "an open courtyard".
     * @param description The room's description.
     */
    public Room(String description) 
    {
        this.description = description;
        this.exits = new HashMap<>();
        this.items = new HashMap<>(); // Initialize the items HashMap
        characters = new HashMap<>();
    }
    
    public void addCharacter(Character character) {
        characters.put(character.getName(), character);
}
    
    public void removeCharacter(Character character) {
        characters.remove(character.getName());
}

public Character getCharacter(String name) {
        return characters.get(name);
}

public Room getRandomExit() {
        Set<String> keys = exits.keySet();
        ArrayList<String> directions = new ArrayList<>(keys);
        if (directions.isEmpty()) {
            return null;
        }
        String randomDirection = directions.get(new Random().nextInt(directions.size()));
        return exits.get(randomDirection);
    }

    public HashMap<String, Item> getItems() {
        return items;
    }   
    
    public String getDescription() {
        return description;
    }
    
    public void addItem(String name, Item item) {
        items.put(name, item);
    }

    // Method to retrieve an item
    public Item getItem(String name) {
        return items.get(name);
    }

    // Method to remove an item
    public void removeItem(String name) {
        items.remove(name);
    }
    
    /**
     * Define an exit from this room.
     * @param direction The direction of the exit.
     * @param neighbor  The room to which the exit leads.
     */
    public void setExit(String direction, Room neighbor) 
    {
        exits.put(direction, neighbor);
    }

    /**
     * @return The short description of the room
     * (the one that was defined in the constructor).
     */
    public String getShortDescription()
    {
        return description;
    }

    /**
     * Return a description of the room in the form:
     *     You are in the kitchen.
     *     Exits: north west
     * @return A long description of this room
     */
    public String getLongDescription()
    {
        return "You are " + description + ".\n" + getExitString();
    }

    /**
     * Return a string describing the room's exits, for example
     * "Exits: north west".
     * @return Details of the room's exits.
     */
    public String getExitString() {
        String returnString = "Exits:";
        Set<String> keys = exits.keySet();
        for (String exit : keys) {
            returnString += " " + exit;
        }
        return returnString;
    }

    public String getExitsDescription() {
        return getExitString();
    }   
    
    /**
     * Return the room that is reached if we go from this room in direction
     * "direction". If there is no room in that direction, return null.
     * @param direction The exit's direction.
     * @return The room in the given direction.
     */
    public Room getExit(String direction) 
    {
        return exits.get(direction);
    }
}
