import java.util.HashMap;
import java.util.Stack;
import java.util.ArrayList; 
import java.util.Arrays;
/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2016.02.29
 */

public class Game 
{
    private Room outside, theater, pub, lab, office, library, studyRoom;
    private static final int MAX_WEIGHT = 10;
    private int currentWeight = 0;
    private Parser parser;
    private Room currentRoom;
    private Stack<Room> roomHistory;  // New attribute for 'back' command   
    private HashMap<String, Item> inventory;  // New attribute for player inventory
    private HashMap<String, Room> exits;  // Declare the exits variable
    private HashMap<String, Item> currentRoomItems;
    private Room magicTransporterRoom; // Declare the magic transporter room CHALLENGE TASK
    private ArrayList<Character> characters;  // To store all characters


    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        roomHistory = new Stack<>();
        createRooms();
        parser = new Parser();
        inventory = new HashMap<>();
        characters = new ArrayList<>();
        exits = new HashMap<>(); // Initialize the exits map
        magicTransporterRoom = new TransporterRoom("a mystical room with swirling portals", new ArrayList<>(Arrays.asList(outside, theater, pub, lab, office, library, studyRoom)));
    }

    
    private void createCharacters() {
        Character professor = new Character("Professor", lab); // 
        lab.addCharacter(professor);
        characters.add(professor);
        currentRoom = outside;
        currentRoomItems = outside.getItems();
    }
    
    
        
    
    private void transportPlayerToRandomRoom() {
    }
    
    
    
    
    public String getExitsDescription()
    {
     StringBuilder exitString = new StringBuilder("Exits: ");
        for (String direction : exits.keySet()) {
            exitString.append(direction).append(" ");
        }
        return exitString.toString();
    }   

    

    private void printRoomExits(Room room)
    {
        System.out.println(room.getExitsDescription());
    }
    
    
    private void printRoomSetup()
    {
        System.out.println("Room Setup:");
        if (outside != null) printRoomExits(outside);
        if (theater != null) printRoomExits(theater);
        if (pub != null) printRoomExits(pub);
        if (lab != null) printRoomExits(lab);
        if (office != null) printRoomExits(office);
        if (library != null) printRoomExits(library);
        if (studyRoom != null) printRoomExits(studyRoom);
    }
    
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to Sneak and Cheat!");
        System.out.println("Sneak and Cheat is a simple text-based adventure game.");
        System.out.println("Your goal is to find the 'class test answers' and bring them to the 'study room' to win. You have been slacking on work, and the exam is nearing. No time to study!");
        System.out.println("Type 'help' if you need assistance with commands.");
        System.out.println();
        printRoomSetup(); // Print room setup information
        printRoomItems(currentRoom); // Print items in the current room

    }
    
    public Item getItem(String name) {
    return currentRoomItems.get(name);
}
    
    
    private void printRoomItems(Room room) {
    System.out.println("Items in the room:");
    for (Item item : room.getItems().values()) {
        System.out.println(item.getName());
    }
}
    
    
    // Method to process 'take' command
    private void takeItem(Command command) {
        String itemName = command.getSecondWord();
        System.out.println("Attempting to take: " + itemName);
      if (!command.hasSecondWord()) {
        System.out.println("Take what?");
        return;
    }
    
    Item item = currentRoom.getItem(itemName);

    if (item == null) {
        System.out.println("That item is not here.");
    } else if (!item.canBePickedUp()) {
        System.out.println("You can't pick that up.");
    } else if (currentWeight + item.getWeight() > MAX_WEIGHT) {
        System.out.println("It's too heavy to carry.");
    } else {
        inventory.put(itemName, item); // Add the item to the player's inventory
        currentRoom.removeItem(itemName); // Remove the item from the room
        currentWeight += item.getWeight();
        System.out.println("Taken: " + itemName); // Debugging message
    }
}

public void dropItem(Command command) {
    if (!command.hasSecondWord()) {
        System.out.println("Drop what?");
        return;
    }
    String itemName = command.getSecondWord();
    Item item = inventory.get(itemName);

    if (item == null) {
        System.out.println("You don't have that item.");
    } else {
        currentRoom.addItem(itemName, item); // Add the item back to the room
        inventory.remove(itemName); // Remove the item from the inventory
        currentWeight -= item.getWeight();
        System.out.println("Dropped.");
    }
}

    
    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Room outside, theater, pub, lab, office, library, studyRoom, magicTransporterRoom;
        outside = new Room("outside the main entrance of the university");
        theater = new Room("in a lecture theater");
        pub = new Room("in the campus pub");
        lab = new Room("in a computing lab");
        office = new Room("in the computing admin office");
        library = new Room("in the university library");
        studyRoom = new Room("in the study room");
        magicTransporterRoom = new TransporterRoom("a mystical room with swirling portals", new ArrayList<>(Arrays.asList(outside, theater, pub, lab, office, library)));

        // Initialize room exits
       outside.setExit("east", theater);
        outside.setExit("west", pub);
        outside.setExit("north", lab);

        theater.setExit("west", outside);
        pub.setExit("east", outside);
    
        lab.setExit("south", outside);
        lab.setExit("east", office);
        lab.setExit("transporter", magicTransporterRoom); // add an exit to the transporter room

        office.setExit("west", lab);
        office.setExit("east", library); // Assuming this exit

        library.setExit("west", office); // Corresponding exit from library to office
        library.setExit("east", studyRoom);

        studyRoom.setExit("west", library);

        // Set the initial current room
        currentRoom = outside;
        currentRoomItems = outside.getItems();

        // Add the "class test answers" item to the theater room
        Item classTestAnswers = new Item("class test answers", "Answers to the class test.", 1, true);
        theater.addItem("class test answers", classTestAnswers);

        // Add the "office key" item to the office room
        Item officeKey = new Item("office key", "A key to the office.", 1, true);
        office.addItem("office key", officeKey);

        ArrayList<Room> allRooms = new ArrayList<>(Arrays.asList(outside, theater, pub, lab, office, library, studyRoom));
        
    }




        private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if (command.isUnknown()) {
            System.out.println("I don't know what you mean...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("help")) {
            printHelp();
        } else if (commandWord.equals("go")) {
            goRoom(command);
        } else if (commandWord.equals("take")) {
            takeItem(command);
        } else if (commandWord.equals("back")) {
            goBack();
        } else if (commandWord.equals("quit")) {
            wantToQuit = quit(command);
        }
        
        return wantToQuit;
    }

    private void printHelp() 
    {
    System.out.println("You are lost. You are alone. You wander");
    System.out.println("around at the university.");
    System.out.println();
    System.out.println("Your command words are:");
    System.out.println("go quit help take drop back"); // List all available commands, including "back"
    }

    private void goRoom(Command command) 
    {
        if (!command.hasSecondWord()) {
        System.out.println("Go where?");
        return;
    }

    String direction = command.getSecondWord();
    Room nextRoom = currentRoom.getExit(direction);

    if (nextRoom == null) {
        System.out.println("There is no door!");
    } else {
        roomHistory.push(currentRoom); // Remember the current room
        currentRoom = nextRoom; // Change to the next room
        currentRoomItems = nextRoom.getItems(); // Update items in the current room

        System.out.println(currentRoom.getLongDescription());
        printRoomItems(currentRoom); // Optionally print items in the new room
    }
    
    if (currentRoom instanceof TransporterRoom) {
        currentRoom = ((TransporterRoom) currentRoom).getRandomRoom();
        System.out.println("You've been magically transported to " + currentRoom.getShortDescription());
    }
    }

    private void goBack() {
    if (roomHistory.isEmpty()) {
        System.out.println("No way back!");
        return;
    }

    Room previousRoom = roomHistory.pop();
    currentRoom = previousRoom;
    System.out.println(currentRoom.getLongDescription());
    printRoomExits(currentRoom); // Print the exits in the new room
    printRoomItems(currentRoom); // Print items in the new room
}

    private boolean checkWin() {
    if (currentRoom.getShortDescription().equals("in the study room") && 
        inventory.containsKey("class test answers")) {
        return true;
    }
    return false;
}
    
    public void play() {            
    printWelcome();

    boolean finished = false;
    while (!finished) {
        Command command = parser.getCommand();
        finished = processCommand(command);
        if (checkWin()) {
            System.out.println("Congratulations! You have won the game!");
            finished = true;
        }
    }
    while (!finished) {
        moveCharacters();
    }
    
    System.out.println("Thank you for playing. Goodbye.");
}   

private void moveCharacters() {
    for (Character character : characters) {
        character.moveRandomly();
    }
}


 private void talkToCharacter(Command command) {
    if (!command.hasSecondWord()) {
        System.out.println("Talk to whom?");
        return;
    }

    String characterName = command.getSecondWord();
    Character character = currentRoom.getCharacter(characterName);
    if (character != null) {
        character.interact();
    } else {
        System.out.println("There is no one named " + characterName + " here.");
    }
    }


    private boolean quit(Command command) 
    {
        if (command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        } else {
            return true;
        }
    }
}

