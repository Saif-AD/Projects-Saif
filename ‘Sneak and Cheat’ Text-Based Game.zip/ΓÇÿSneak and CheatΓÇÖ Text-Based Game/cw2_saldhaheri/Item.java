
/**
 * Write a description of class Item here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

public class Item {
    private String name;
    private String description;
    private int weight;
    private boolean canBePickedUp;

    public Item(String name, String description, int weight, boolean canBePickedUp) {
        this.name = name;
        this.description = description;
        this.weight = weight;
        this.canBePickedUp = canBePickedUp;
    }

    // Getters for the fields
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getWeight() {
        return weight;
    }

    public boolean canBePickedUp() {
        return canBePickedUp;
    }
}


