import java.util.ArrayList;
/**
 * Write a description of class TransporterRoom here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TransporterRoom extends Room {
    private ArrayList<Room> rooms;

    public TransporterRoom(String description, ArrayList<Room> rooms) {
        super(description);
        this.rooms = rooms;
    }

    public Room getRandomRoom() {
        int index = (int) (Math.random() * rooms.size());
        return rooms.get(index);
    }
    
    
}