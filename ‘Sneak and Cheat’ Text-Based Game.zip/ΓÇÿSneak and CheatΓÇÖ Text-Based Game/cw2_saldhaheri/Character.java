import java.util.Random;
/**
 * Write a description of class Character here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Character {
    private String name;
    private Room currentRoom;
    
    public String getName() {
        return name;
    }

    public void interact() {
        System.out.println(name + " says hello!");
    }
    
    public Character(String name, Room startRoom) {
        this.name = name;
        this.currentRoom = startRoom;
    }

    // Method to randomly move the character to a different room
    public void moveRandomly() {
        Room nextRoom = currentRoom.getRandomExit();
        if (nextRoom != null) {
            currentRoom.removeCharacter(this);
            nextRoom.addCharacter(this);
            currentRoom = nextRoom;
        }
    }
}
